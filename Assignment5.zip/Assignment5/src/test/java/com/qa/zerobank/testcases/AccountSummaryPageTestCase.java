package com.qa.zerobank.testcases;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.zerobank.base.TestBase;
import com.qa.zerobank.pages.AccountSummaryPage;
import com.qa.zerobank.pages.HomePage;
import com.qa.zerobank.pages.LoginPage;

import com.qa.zerobank.util.TestUtil;

public class AccountSummaryPageTestCase extends TestBase {
	
	HomePage homepage;
	LoginPage loginPage;
	AccountSummaryPage accountSummaryPage;

	TestUtil testUtil;
	
 
  @BeforeMethod
  public void beforeMethod() {
	  initialization();
	  homepage = new HomePage();
	  loginPage = new LoginPage();
	  testUtil = new TestUtil();
  }

  @AfterMethod
  public void afterMethod() throws IOException {
	 // testUtil.takeScreenshotAtEndOfTest("LogInPage");
	  driver.close();
	  driver.quit();
  } 
 
  
  @Test
 	public void fundTransfertest() {
	  loginPage = homepage.clickOnSignInButton();
	  accountSummaryPage = loginPage.verifylogin("username","password");
	  accountSummaryPage.assertAccountSummaryPageTitle();
 	  accountSummaryPage.FundTransfer();
 		
 	}
}


