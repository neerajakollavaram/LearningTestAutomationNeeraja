package com.qa.zerobank.pages;
import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.testng.asserts.SoftAssert;

import com.qa.zerobank.base.TestBase;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AccountSummaryPage extends TestBase {

		
		@FindBy(xpath = "//a[contains(text(),'Pay Bills')]")
		WebElement paybills;

		@FindBy(xpath = "//input[@id='tf_amount']")
		WebElement transferamount;

		@FindBy(xpath= "//input[@id='tf_description']")
		WebElement description;

		@FindBy(xpath = "[name='user_remember_me]")
		WebElement userremainme;

		@FindBy(xpath = "//button[@id='btn_submit']")
		WebElement submitbutton;
		
		@FindBy(xpath = "//h2[contains(text(),'Transfer Money & Make Payments - Verify')]")
		WebElement transfermoneytext;
		
		@FindBy(linkText = "Pay Bills")
		WebElement PayBills;
		
		@FindBy(linkText = "Purchase Foreign Currency")
		WebElement purchaseforeigncurrency;
		
		@FindBy(css = "input#purchase_cash[type='submit']")
		WebElement purchasesubmit;																											
		
		@FindBy(xpath = "//a[contains(text(),'Transfer Funds')]")
		WebElement Transfunds;	
		
																																																																		
		 SoftAssert As = new SoftAssert();
		

		public AccountSummaryPage() {
			PageFactory.initElements(driver, this);
		}

		public void assertAccountSummaryPageTitle() {
			assertEquals(driver.getTitle(),"Zero - Account Summary");
		}
		
		public void FundTransfer() {
			Transfunds.click();
			transferamount.sendKeys("1000");
			description.sendKeys("abc");
			submitbutton.click();
			
			String actualTitle =transfermoneytext.getText();
			String expectedTitle = "Transfer Money & Make Payments - Verify";
			As.assertEquals(actualTitle, expectedTitle);
			
			
		}
		public void purchaseEmptyFieldValidation() {
			paybills.click();
			purchaseforeigncurrency.click();
			purchasesubmit.click();
			Alert jsAlert = driver.switchTo().alert();
			//driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
			jsAlert.accept();
			
			
			
			
		}

}
