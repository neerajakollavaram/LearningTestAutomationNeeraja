package com.zerobank.qa.TestCode;

public class PurchaseForeignCurrency_steps {

}
