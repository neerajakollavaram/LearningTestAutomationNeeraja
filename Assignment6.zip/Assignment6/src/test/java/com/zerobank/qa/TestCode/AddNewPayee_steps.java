package com.zerobank.qa.TestCode;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;

public class AddNewPayee_steps {
	
		public static WebDriver driver;

	    @Given("^A \"([^\"]*)\" browser initialized$")
	    public void initiateBrowser(String browser) {
	        //Set system properties
	        System.setProperty("webdriver.chrome.driver","C:\\SeleniumBrowserDrivers\\chromedriver.exe");
	        // create driver object
	        driver = new ChromeDriver();        
	        driver.manage().window().maximize();
	        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	    
	}

	@Given("^I am on Account Summary Page$")
	public void i_am_on_Account_Summary_Page() {
	}

	@When("^I click PayBills And I click on Add New Payee I land on Add New Payee$")
	public void i_click_PayBills_And_I_click_on_Add_New_Payee_I_land_on_Add_New_Payee() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I Select Payee Name As \"([^\"]*)\"and PayeeAddress As \"([^\"]*)\"and Account As \"([^\"]*)\" and PayeeDetails As\"([^\"]*)\"$")
	public void i_Select_Payee_Name_As_and_PayeeAddress_As_and_Account_As_and_PayeeDetails_As(String arg1, String arg2, String arg3, String arg4) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^click on Add button$")
	public void click_on_Add_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^I get message that Payee was added successfully\\.$")
	public void i_get_message_that_Payee_was_added_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^I am on AccountSummaryPage$")
	public void i_am_on_AccountSummaryPage() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I enter Name as \"([^\"]*)\" and Address as \"([^\"]*)\" and PayeeAccount as \"([^\"]*)\"$")
	public void i_enter_Name_as_and_Address_as_and_PayeeAccount_as(String arg1, String arg2, String arg3) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^Click on Add button$")
	public void click_on_Add_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^In validate that I get an error message \"([^\"]*)\"$")
	public void in_validate_that_I_get_an_error_message(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^I enter Name as Neeraja and Address as Plot No:(\\d+) and PayeeAccount as \"([^\"]*)\"$")
	public void i_enter_Name_as_Neeraja_and_Address_as_Plot_No_and_PayeeAccount_as(int arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}


}
